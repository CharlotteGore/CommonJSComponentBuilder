require.register("<%=moduleName%>", function(exports, require, module){
<%=moduleContent%>
});
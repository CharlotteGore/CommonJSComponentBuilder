(function(){
<%=assemblyContent%>
})();
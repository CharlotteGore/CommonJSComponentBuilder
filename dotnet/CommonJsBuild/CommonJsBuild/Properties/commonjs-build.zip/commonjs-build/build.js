var program = require('commander');
var path = require('path');
var fs = require('fs');

program
	.version('0.0.1')
	.option('-e, --entry [file]', 'Entry point')
	.option('-o, --output [file]', 'Output')
	.option('-t, --templates [file]', 'Template folder')
	.parse(process.argv);

// load the includes. Relative the node exe and this script.

if(program.entry && program.output){ 

	var templateUri = path.join(process.cwd(), program.templates);

	var includes = {
		assembly : 	fs.readFileSync( path.join(templateUri, 'assembly.js'), "utf8"),
		module : fs.readFileSync( path.join(templateUri ,'module.js'), "utf8"),
		require : fs.readFileSync( path.join( templateUri, 'require.js') , "utf8")
	}

	var compiledModules = [];

	var entryUri = path.join( process.cwd(), program.entry );
	var outputUri = path.normalize(path.join(process.cwd(), program.output));
	var componentsUri = path.join( path.dirname(entryUri), "/components" )

	var entryJS = fs.readFileSync(entryUri, 'utf8');

	var components = fs.readdirSync( componentsUri );

	components.forEach(function( folder ){

		var data = require( path.join(componentsUri , folder, '/component.json') );

		data.scripts.forEach(function( script ){

			var content = fs.readFileSync( path.join(componentsUri, folder, script ) );
			var compiled = (includes.module.replace('<%=moduleContent%>', content)).replace('<%=moduleName%>', folder + "/" + script);

			compiledModules.push(compiled);
			//console.log( path.join(componentsUri, folder, script) );

		})

	});

	var assembly = includes.require;
	compiledModules.forEach(function( module ){

		assembly += "\n" + module;

	})

	assembly += "\n" + entryJS;

	var finalOutput = includes.assembly.replace('<%=assemblyContent%>', assembly);

	fs.writeFileSync(outputUri, finalOutput, 'utf8');

	console.log("Done");

} else {

	console.log('    $ build --help');

}
